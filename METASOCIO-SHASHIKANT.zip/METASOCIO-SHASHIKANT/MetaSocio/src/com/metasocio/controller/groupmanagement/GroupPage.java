package com.metasocio.controller.groupmanagement;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.metasocio.exception.MetaSocioSystemException;
import com.metasocio.model.commentmanagement.Comment;
import com.metasocio.model.groupmanagement.Group;
import com.metasocio.model.postmanagement.Post;
import com.metasocio.model.usermanagement.User;
import com.metasocio.service.commentmanagement.CommentService;
import com.metasocio.service.followermanagement.FollowerService;
import com.metasocio.service.groupmanagement.GroupService;
import com.metasocio.service.likemanagement.LikeService;
import com.metasocio.service.postmanagement.PostService;
import com.metasocio.service.usermanagement.UserService;

/**
 * Servlet implementation class HomePage
 */
@WebServlet("/GroupPage")
public class GroupPage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public GroupPage() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session=request.getSession(false);
		int groupId = Integer.parseInt(request.getParameter("groupId"));
		 User user = (User) session.getAttribute("userObject");
	
		GroupService iGroupService = new GroupService();
		UserService iUserService = new UserService();
		PostService iPostService = new PostService();
			
		try {
			Group group = iGroupService.getGroupById(groupId);
					
			User groupMember = iUserService.getUserByEmail(user.getEmailId());		
			
			CommentService iCommentService = new CommentService();
			
			
			//System.out.println("groupPage ------------------department"+ groupMember.getDepartment() + " Id "+group.getGroupId() );
			
			List<User> usersOfSamedepartmentWhoAreNotGroupMembers = iGroupService
					.getUsersHavingSameDepartment(groupMember.getDepartment(), group.getGroupId());
			request.setAttribute("userObject", groupMember);
			
			request.setAttribute("groupObject", group);
			
			
			Map<Post, List<Comment>> postMap = new LinkedHashMap<Post, List<Comment>>();
			int startIndex = 0;
			int maximumResult = 2;
			List<Post> postsWithImage = iPostService.retrievePostWithImageOnHome(startIndex,maximumResult,group.getGroupId());
		
			
			LikeService iLikeService  = new LikeService();
			Map<Post, Boolean> likeMap = new LinkedHashMap<Post,Boolean>();
			
			for (Post post : postsWithImage) 
			{
				boolean isLikedByUser = iLikeService.hasUSerAlreadyLiked(groupMember.getUserId(),post.getPostId());
				// Adding to the list with comment
				List<Comment> commentsWithImage = iCommentService.retrieveCommentListWithImageByPostID(post.getPostId());
				// puts the post with image
				postMap.put(post, commentsWithImage);
				likeMap.put(post, isLikedByUser);
			}

			FollowerService iFollowerService=new FollowerService();
			List<User> followersList = iFollowerService.getFollowers(user);
			

			if(!usersOfSamedepartmentWhoAreNotGroupMembers.isEmpty()){
				request.setAttribute("suggestedUser", usersOfSamedepartmentWhoAreNotGroupMembers.get(usersOfSamedepartmentWhoAreNotGroupMembers.size()-1));
			}
			request.setAttribute("followerList", followersList);
			System.out.println("post size "+postMap.size());
			request.setAttribute("postMap", postMap);
			request.setAttribute("likeMap", likeMap);
			
			request.getRequestDispatcher("./view/groupmanagement/group.jsp")
					.forward(request, response);
		} catch (MetaSocioSystemException e) {
			
			//System.out.println("[" + e.getMessage() + "]");
			request.setAttribute("message", "[" + e.getMessage() + "]");
			request.getRequestDispatcher("./exception/error.jsp").forward(
					request, response);
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	
	
	
}
