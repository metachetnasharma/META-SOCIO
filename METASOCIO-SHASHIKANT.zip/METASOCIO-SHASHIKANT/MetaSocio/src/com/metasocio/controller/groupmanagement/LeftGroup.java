package com.metasocio.controller.groupmanagement;

import java.io.IOException;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.hibernate.Hibernate;

import com.metasocio.dbhelper.usermanagement.UserDao;
import com.metasocio.exception.MetaSocioSystemException;
import com.metasocio.model.groupmanagement.Group;
import com.metasocio.model.usermanagement.User;
import com.metasocio.service.groupmanagement.GroupService;
import com.metasocio.service.usermanagement.UserService;

/**
 * Servlet implementation class AddFriend
 */
@WebServlet("/LeftGroup")
public class LeftGroup extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LeftGroup() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession(false);
		User user = (User) session.getAttribute("userObject");
		UserService iUserService = new UserService();
		
		int groupId = Integer.parseInt(request.getParameter("groupId"));
		GroupService iGroupService = new GroupService();
		System.out.println("in left contrller groupId "+groupId);
		try {	
			User leftingUser = iUserService.getUserByEmail(user.getEmailId());	
			Group group = iGroupService.getGroupById(groupId);
			
				Set<User> membersSet = group.getUsersSet();
				
				for(User u : membersSet){
				
				System.out.println("-------------------------------in left before "+ u.getName());
				}
				
				group.getUsersSet().clear();
			
				for(User u : group.getUsersSet()){
					
					System.out.println("-------------------------------in left after "+ u.getName());
					}
				
				iGroupService.updateGroup(group);
		
				group.setUsersSet(membersSet);
				iGroupService.updateGroup(group);
				
				response.sendRedirect("HomePage");					
			
		} catch (MetaSocioSystemException e) {
		
			request.setAttribute("message","["+e.getMessage()+"]");
			request.getRequestDispatcher("./exception/error.jsp").forward(request, response);
		}
		
	}	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
