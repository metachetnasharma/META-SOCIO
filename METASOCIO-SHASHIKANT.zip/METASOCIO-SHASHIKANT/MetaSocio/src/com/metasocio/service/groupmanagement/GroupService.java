package com.metasocio.service.groupmanagement;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.metasocio.exception.MetaSocioSystemException;
import com.metasocio.facade.groupmanagement.GroupFacade;
import com.metasocio.hibernate.factory.ConfigurationFactory;
import com.metasocio.model.groupmanagement.Group;
import com.metasocio.model.usermanagement.User;

public class GroupService {

	public int createGroup(Group group) throws MetaSocioSystemException {
		Session session = null;
		int groupId = 0;
		// boolean isUserExists=false;
		SessionFactory sessionFactory=null;
		Transaction transaction = null;
		// String userName;
		try {
			

			GroupFacade iGroupFacade = new GroupFacade();
			Configuration cfg =ConfigurationFactory.getConfigurationInstance();
			// Session Factory is Called
			sessionFactory = cfg.buildSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			groupId = iGroupFacade.createGroup(group, session);

			transaction.commit();

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("[" + e.getMessage() + "]");
			try {
				transaction.rollback();
				System.out.println("Transaction roll back");
				throw new MetaSocioSystemException("Transaction roll back,["
						+ e.getMessage() + "]", e);
			} catch (Exception e1) {
				e.printStackTrace();
				System.out.println("error in transactiopn roll back,["
						+ e1.getMessage() + "]");
				throw new MetaSocioSystemException("[" + e.getMessage()
						+ "];error in transactiopn roll back,["
						+ e1.getMessage() + "]", e);
			}
		} finally {
			if (session != null) {
				session.close();
			}
			if(sessionFactory!=null){
				sessionFactory.close();
			}
		}
		return groupId;
	}

	public Group getGroupById(int groupId) throws MetaSocioSystemException {
		Session session = null;
		Group group = new Group();
		SessionFactory sessionFactory=null;
		Transaction transaction = null;
		// String userName;
		try {
		
			GroupFacade iGroupFacade = new GroupFacade();
			Configuration cfg =ConfigurationFactory.getConfigurationInstance();
			// Session Factory is Called
			sessionFactory = cfg.buildSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			group = iGroupFacade.getGroupById(groupId, session);

			transaction.commit();

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("[" + e.getMessage() + "]");
			try {
				transaction.rollback();
				System.out.println("Transaction roll back");
				throw new MetaSocioSystemException("Transaction roll back,["
						+ e.getMessage() + "]", e);
			} catch (Exception e1) {
				e.printStackTrace();
				System.out.println("error in transactiopn roll back,["
						+ e1.getMessage() + "]");
				throw new MetaSocioSystemException("[" + e.getMessage()
						+ "];error in transactiopn roll back,["
						+ e1.getMessage() + "]", e);
			}
		} finally {
			if (session != null) {
				session.close();
			}
			if(sessionFactory!=null){
				sessionFactory.close();
			}
		}
		return group;
	}

	public void updateGroup(Group group) throws MetaSocioSystemException {
		Session session = null;
		// boolean isUserExists=false;
		Transaction transaction = null;
		SessionFactory sessionFactory=null;
		// String userName;
		try {
	
			GroupFacade iGroupFacade = new GroupFacade();
			Configuration cfg =ConfigurationFactory.getConfigurationInstance();
			// Session Factory is Called
			sessionFactory = cfg.buildSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			iGroupFacade.updateGroup(group, session);

			transaction.commit();

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("[" + e.getMessage() + "]");
			try {
				transaction.rollback();
				System.out.println("Transaction roll back");
				throw new MetaSocioSystemException("Transaction roll back,["
						+ e.getMessage() + "]", e);
			} catch (Exception e1) {
				e.printStackTrace();
				System.out.println("error in transactiopn roll back,["
						+ e1.getMessage() + "]");
				throw new MetaSocioSystemException("[" + e.getMessage()
						+ "];error in transactiopn roll back,["
						+ e1.getMessage() + "]", e);
			}
		} finally {
			if (session != null) {
				session.close();
			}
			if(sessionFactory!=null){
				sessionFactory.close();
			}
		}
		// return isAdded;
	}

	public List<Group> getAllGroups() throws MetaSocioSystemException {
		Session session = null;
		List<Group> groupList = new ArrayList<Group>();
		Transaction transaction = null;
		SessionFactory sessionFactory=null;
		// String userName;
		try {
			GroupFacade iGroupFacade = new GroupFacade();
			Configuration cfg =ConfigurationFactory.getConfigurationInstance();
			// Session Factory is Called
			sessionFactory = cfg.buildSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			groupList = iGroupFacade.getAllGroups(session);

			transaction.commit();

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("[" + e.getMessage() + "]");
			try {
				transaction.rollback();
				System.out.println("Transaction roll back");
				throw new MetaSocioSystemException("Transaction roll back,["
						+ e.getMessage() + "]", e);
			} catch (Exception e1) {
				e.printStackTrace();
				System.out.println("error in transactiopn roll back,["
						+ e1.getMessage() + "]");
				throw new MetaSocioSystemException("[" + e.getMessage()
						+ "];error in transactiopn roll back,["
						+ e1.getMessage() + "]", e);
			}
		} finally {
			if (session != null) {
				session.close();
			}
			if(sessionFactory!=null){
				sessionFactory.close();
			}
		}
		return groupList;
	}

	public List<Group> getGroupsInWhichUserIsNotMember(User user, List<Group> groupList)
			throws MetaSocioSystemException {
		Session session = null;

		List<Group> groupListInWhichUserIsNotMember = new ArrayList<Group>();
		Transaction transaction = null;
		SessionFactory sessionFactory=null;

		try {
			
			GroupFacade iGroupFacade = new GroupFacade();
			Configuration cfg =ConfigurationFactory.getConfigurationInstance();
			// Session Factory is Called
			sessionFactory = cfg.buildSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			groupListInWhichUserIsNotMember = iGroupFacade.getGroupsInWhichUserIsNotMember(user,
					groupList, session);

			transaction.commit();

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("[" + e.getMessage() + "]");
			try {
				transaction.rollback();
				System.out.println("Transaction roll back");
				throw new MetaSocioSystemException("Transaction roll back,["
						+ e.getMessage() + "]", e);
			} catch (Exception e1) {
				e.printStackTrace();
				System.out.println("error in transactiopn roll back,["
						+ e1.getMessage() + "]");
				throw new MetaSocioSystemException("[" + e.getMessage()
						+ "];error in transactiopn roll back,["
						+ e1.getMessage() + "]", e);
			}
		} finally {
			if (session != null) {
				session.close();
			}
			if(sessionFactory!=null){
				sessionFactory.close();
			}
		}
		return groupListInWhichUserIsNotMember;
	}

	public List<User> getUsersHavingSameDepartment(String department,
			int groupId) throws MetaSocioSystemException {
		Session session = null;
		// boolean isUserExists=false;
		Transaction transaction = null;
		SessionFactory sessionFactory=null;
		List<User> usersOfSameDepartment;
		try {
		
			GroupFacade iGroupFacade = new GroupFacade();

			Configuration cfg =ConfigurationFactory.getConfigurationInstance();
			// Session Factory is Called
			sessionFactory = cfg.buildSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			usersOfSameDepartment = iGroupFacade.getUsersHavingSameDepartment(
					department, groupId, transaction, session);
			transaction.commit();

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("[" + e.getMessage() + "]");
			try {
				transaction.rollback();
				System.out.println("Transaction roll back");
				throw new MetaSocioSystemException("Transaction roll back,["
						+ e.getMessage() + "]", e);
			} catch (Exception e1) {
				e1.printStackTrace();
				System.out.println("error in transactiopn roll back,["
						+ e1.getMessage() + "]");
				throw new MetaSocioSystemException("[" + e.getMessage()
						+ "];error in transactiopn roll back,["
						+ e1.getMessage() + "]", e);
			}
		} finally {
			if (session != null) {
				session.close();
			}
			if(sessionFactory!=null){
				sessionFactory.close();
			}
		}

		return usersOfSameDepartment;
	}

	public List<Group> getMyGroups(int userId) throws MetaSocioSystemException {
		Session session = null;
		// boolean isUserExists=false;
		List<Group> myGroupList = new ArrayList<Group>();
		Transaction transaction = null;
		SessionFactory sessionFactory=null;
		// String userName;
		try {
		
			GroupFacade iGroupFacade = new GroupFacade();
			Configuration cfg =ConfigurationFactory.getConfigurationInstance();
			// Session Factory is Called
			sessionFactory = cfg.buildSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			myGroupList = iGroupFacade.getMyGroups(userId, session);

			transaction.commit();

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("[" + e.getMessage() + "]");
			try {
				transaction.rollback();
				System.out.println("Transaction roll back");
				throw new MetaSocioSystemException("Transaction roll back,["
						+ e.getMessage() + "]", e);
			} catch (Exception e1) {
				e.printStackTrace();
				System.out.println("error in transactiopn roll back,["
						+ e1.getMessage() + "]");
				throw new MetaSocioSystemException("[" + e.getMessage()
						+ "];error in transactiopn roll back,["
						+ e1.getMessage() + "]", e);
			}
		} finally {
			if (session != null) {
				session.close();
			}
			if(sessionFactory!=null){
				sessionFactory.close();
			}
		}
		return myGroupList;
	}

	public int getNumberOfGroups() throws MetaSocioSystemException {
		Session session = null;
		// boolean isUserExists=false;
		Transaction transaction = null;
		SessionFactory sessionFactory=null;
		int numberOfGroups = 0;
		try {
			
			GroupFacade iGroupFacade = new GroupFacade();

			Configuration cfg =ConfigurationFactory.getConfigurationInstance();
			// Session Factory is Called
			sessionFactory = cfg.buildSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			numberOfGroups = iGroupFacade.getNumberOfGroups(transaction, session);
			transaction.commit();

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("[" + e.getMessage() + "]");
			try {
				transaction.rollback();
				System.out.println("Transaction roll back");
				throw new MetaSocioSystemException("Transaction roll back,["
						+ e.getMessage() + "]", e);
			} catch (Exception e1) {
				e1.printStackTrace();
				System.out.println("error in transactiopn roll back,["
						+ e1.getMessage() + "]");
				throw new MetaSocioSystemException("[" + e.getMessage()
						+ "];error in transactiopn roll back,["
						+ e1.getMessage() + "]", e);
			}
		} finally {
			if (session != null) {
				session.close();
			}
			if(sessionFactory!=null){
				sessionFactory.close();
			}
		}

		return numberOfGroups;
	}

}
