/**
 * 
 */
package com.metasocio.validation.userManagement;

import com.metasocio.authentication.SendEmailUtil;
import com.metasocio.model.usermanagement.User;

/******************************************************************************
 * @author : 
 * Since: 28 November,2015
 * Description: SendEmailUtil class is to send success message of signing up 
 * on Meta-Socio  on email-id

 ******************************************************************************/
public class UserValidation {
	
	public void userValidator(name, email, department, role, phnNo){
		if(name.trim()==null || name.trim()=="" || name.trim().isEmpty()){
			String messagePersonalInfo="Please enter your name";
			request.setAttribute("messagePersonalInfo",messagePersonalInfo);
			request.getRequestDispatcher("./view/usermanagement/profile.jsp").forward(request, response);
			
		}
		else if(email==null || email=="" || email.trim()==null || email.trim()=="" || email.trim().isEmpty() ){
			String messagePersonalInfo="Please enter email Id";
			request.setAttribute("messagePersonalInfo",messagePersonalInfo);
			request.getRequestDispatcher("./view/usermanagement/profile.jsp").forward(request, response);
		}
		else if(!email.endsWith("@metacube.com")){
			String messagePersonalInfo="Invalid email";
			request.setAttribute("messagePersonalInfo",messagePersonalInfo);
			request.getRequestDispatcher("./view/usermanagement/profile.jsp").forward(request, response);
		}
		else if(department==null || department=="" || department.trim()==null || department.trim()=="" || department.trim().isEmpty()){
			String messageWorkAndEducation="Please specify your department";
			request.setAttribute("messageWorkAndEducation",messageWorkAndEducation);
			request.getRequestDispatcher("./view/usermanagement/profile.jsp").forward(request, response);
		}
		else if(role==null || role=="" || role.trim()==null || role.trim()=="" || role.trim().isEmpty()){
			String messageWorkAndEducation="Please specify your role in metacube";
			request.setAttribute("messageWorkAndEducation",messageWorkAndEducation);
			request.getRequestDispatcher("./view/usermanagement/profile.jsp").forward(request, response);
		}
		else if(phnNo!="" ){
				if(phnNo.length()!=10){
			String messagePersonalInfo="Phone no. length should not be greater than 10";
			request.setAttribute("messagePersonalInfo",messagePersonalInfo);
			request.getRequestDispatcher("./view/usermanagement/profile.jsp").forward(request, response);
				}
				else if(!phnNo.matches(regex)){
					String messagePersonalInfo="Invalid Phone no";
					request.setAttribute("messagePersonalInfo",messagePersonalInfo);
					request.getRequestDispatcher("./view/usermanagement/profile.jsp").forward(request, response);
				}
		}
		
		else{
		iUserService.setUserInfo(user);
		User newUser=iUserService.getUserByEmail(email);
		
	 	SendEmailUtil sendEmail = new SendEmailUtil();
	 	String emailSubject = newUser.getName()+" welcome to the Metacube network on Meta-Socio";
	 	
	 	String emailBody = "Welcome to Meta-Socio, "+newUser.getName()+" !"
	 			+ "You're now a part of Metacube's private, "
	 			+ "social collaboration network. Meta-Socio makes it easy to work together in teams "
	 			+ "and stay up to date on what others are working on.";
	 	sendEmail.sendEmail(newUser.getEmailId(),emailSubject, emailBody);
		
		session.setAttribute("userObject",newUser);
		response.sendRedirect("HomePage");
		}
	}
