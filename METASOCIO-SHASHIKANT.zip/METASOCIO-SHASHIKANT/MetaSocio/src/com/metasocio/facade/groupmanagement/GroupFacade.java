package com.metasocio.facade.groupmanagement;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.metasocio.dbhelper.groupmanagement.GroupDao;
import com.metasocio.dbhelper.usermanagement.UserDao;
import com.metasocio.exception.MetaSocioException;

import com.metasocio.model.groupmanagement.Group;
import com.metasocio.model.usermanagement.User;

public class GroupFacade {

	public int createGroup(Group group, Session session)
			throws MetaSocioException {
		GroupDao iGroupDao = GroupDao.getInstance();
		int groupId = iGroupDao.createGroup(group, session);
		return groupId;
	}

	public Group getGroupById(int groupId, Session session)
			throws MetaSocioException {

		// CRUD iCrud = CRUD.getInstance();
		GroupDao iGroupDao = GroupDao.getInstance();

		Group group = iGroupDao.getGroupById(groupId, session);
		return group;
	}

	public void updateGroup(Group group, Session session) throws MetaSocioException {
		GroupDao iGroupDao = GroupDao.getInstance();
		iGroupDao.updateGroup(group, session);
	}

	public List<Group> getAllGroups(Session session) throws MetaSocioException {
		GroupDao iGroupDao = GroupDao.getInstance();
		List<Group> groupList = iGroupDao.getAllGroups(session);
		return groupList;
	}

	public List<Group> getGroupsInWhichUserIsNotMember(User user, List<Group> groupList,
			Session session) throws MetaSocioException {
		// CRUD iCrud = CRUD.getInstance();
		GroupDao iGroupDao = GroupDao.getInstance();
		List<Group> groupListInWhichUserIsNotMember = iGroupDao.getGroupsInWhichUserIsNotMember(user,
				groupList, session);

		return groupListInWhichUserIsNotMember;
	}

	public List<User> getUsersHavingSameDepartment(String department,
			int groupId, Transaction transaction, Session session)
			throws MetaSocioException {
		UserDao iUserDao = UserDao.getInstance();
		GroupDao iGroupDao = GroupDao.getInstance();
		List<User> users = iUserDao.getUsersHavingSameDepartment(department,
				session);
		List<User> usersHavingSameDepartment = iGroupDao
				.getUsersWhoAreNotGroupMembers(groupId, users, session);
		return usersHavingSameDepartment;
	}

	public List<Group> getMyGroups(int userId, Session session)
			throws MetaSocioException {
		GroupDao iGroupDao = GroupDao.getInstance();
		List<Group> myGroupList = iGroupDao.getMyGroups(userId, session);

		return myGroupList;
	}

	public int getNumberOfGroups(Transaction transaction, Session session) throws MetaSocioException {
		GroupDao iGroupDao = GroupDao.getInstance();
		int numberOfGroups = iGroupDao.getNumberOfGroups(session);

		return numberOfGroups;
	}
}
