package com.metasocio.authentication.filter;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**************************************************************************
 * @author Since : 6 December, 2015 Description : This filter will manage
 *         session for complete application /
 **************************************************************************/
@WebFilter("/*")
public class SessionManagement implements Filter {
	private ServletContext context;

	/**
	 * Default constructor.
	 */
	public SessionManagement() {
	}

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
	}

	/********************************************************************************
	 * This function will manage session.It will call each time when user
	 * redirects to controller or jsp page and check session if session is null
	 * then redirects the user to index jsp page otherwise forward to the
	 * requested jsp page or controller
	 * 
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 ***********************************************************************************/
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		System.out.println("filter 1");
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
		String uri = req.getRequestURI(); // getting requested uri
		this.context.log("Requested Resource::" + uri);
		HttpSession session = req.getSession(false); // getting http session
		// it will check either session null or not if session is null then it
		// will redirect to index jsp page
		if (session == null
				&& (uri.endsWith("AddComment") || uri.endsWith("AddFriend")
						|| uri.endsWith("LogOut")
						|| uri.endsWith("LikeManager")
						|| uri.endsWith("AddPost") || uri.endsWith("HomePage")
						|| uri.endsWith("CreateUserProfile")
						|| uri.endsWith("home.jsp") || uri
							.endsWith("profile.jsp"))) {
			this.context.log("Unauthorized access request");
			String message = "Unauthorized access request,Please Login first";
			request.setAttribute("message", message);
			request.getRequestDispatcher("index.jsp").forward(req, res);
		} else {
			chain.doFilter(request, response);
		}
	}

	/********************************************************************************
	 * @see Filter#init(FilterConfig)
	 ***********************************************************************************/
	public void init(FilterConfig fConfig) throws ServletException {
		this.context = fConfig.getServletContext();
		this.context.log("AuthenticationFilter initialized");
	}
}
